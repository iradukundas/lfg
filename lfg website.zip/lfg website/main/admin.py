from django.contrib import admin
from .models import ToDoList
# Register your models here.
admin.site.register(ToDoList)